# Denora Discord Bot

> 1st Web3 Growth Studio — Official Discord Bot  
> Built with discord.js v14 | Node.js

---

## Features

| Module | Commands |
|---|---|
| 🎨 Creator Card | Auto-generated on join — deep blue Denora-branded card |
| 🎫 Tickets | `/ticket open`, `/ticket list` |
| 👤 KOL Management | `/kol add/remove/assign/deliverable/payment/info/list` |
| 📊 Campaigns | `/campaign create/update/status/setstatus/list` |
| 🚀 Onboarding | `/onboard` |
| 🔨 Moderation | `/mod warn/warnings/kick/ban` |
| 📈 Reports | `/report kols/campaigns/clients/server` |

---

## Setup

### 1. Prerequisites
- Node.js v18+
- A Discord application + bot token from [Discord Developer Portal](https://discord.com/developers/applications)

### 2. Install
```bash
unzip denora-bot.zip
cd denora-bot
npm install
```

### 3. Configure
Open the `.env` file and fill in your values:

```env
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_application_id
GUILD_ID=your_server_id

WELCOME_CHANNEL_ID=
TICKET_CHANNEL_ID=
REPORTS_CHANNEL_ID=
MOD_LOG_CHANNEL_ID=

CLIENT_ROLE_ID=
TEAM_ROLE_ID=
KOL_ROLE_ID=
ADMIN_ROLE_ID=
COMMUNITY_ROLE_ID=
```

**How to get IDs in Discord:** Enable Developer Mode (Settings → Advanced → Developer Mode), then right-click any channel/role/server and click "Copy ID".

### 4. Deploy Slash Commands
```bash
npm run deploy
```

### 5. Start the Bot
```bash
npm start        # production
npm run dev      # development (auto-restart)
```

---

## Bot Permissions Required

In the Discord Developer Portal under **OAuth2 → Bot**, enable:
- Send Messages, Manage Messages, Manage Threads
- Create Private Threads, Manage Roles
- Kick Members, Ban Members
- View Channels, Read Message History

**Privileged Gateway Intents (Bot tab):**
- ✅ Server Members Intent
- ✅ Message Content Intent

---

## Project Structure

```
denora-bot/
├── index.js
├── deploy-commands.js
├── .env                        ← fill this in
├── .env.example
├── commands/
│   ├── tickets/ticket.js
│   ├── kol/kol.js
│   ├── campaigns/campaign.js
│   ├── onboarding/onboard.js
│   ├── moderation/mod.js
│   └── reports/report.js
├── events/
│   ├── ready.js
│   ├── guildMemberAdd.js       ← welcome + role buttons
│   └── interactionCreate.js   ← slash commands + buttons + creator card
├── utils/
│   ├── db.js                   ← JSON storage
│   ├── embeds.js               ← Denora-branded embeds
│   └── creatorCard.js          ← creator card image generator
└── data/                       ← auto-created on first run
    ├── kols.json
    ├── campaigns.json
    ├── tickets.json
    ├── clients.json
    └── warnings.json
```

---

*Built for Denora — 1st Web3 Growth Studio combining strategy, execution and talent.*
