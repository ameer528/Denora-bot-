const { SlashCommandBuilder } = require('discord.js');
const { embeds } = require('../../utils/embeds');
const db = require('../../utils/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('onboard')
    .setDescription('Onboard a new Denora client')
    .addUserOption(o => o.setName('user').setDescription('Discord user to onboard').setRequired(true))
    .addStringOption(o => o.setName('company').setDescription('Company or project name').setRequired(true))
    .addStringOption(o => o.setName('package').setDescription('Retainer package').setRequired(true)
      .addChoices(
        { name: 'Starter', value: 'Starter' },
        { name: 'Growth', value: 'Growth' },
        { name: 'Scale', value: 'Scale' },
        { name: 'Enterprise', value: 'Enterprise' },
        { name: 'Custom', value: 'Custom' },
      ))
    .addStringOption(o => o.setName('niche').setDescription('Project niche (DeFi, GameFi, NFT, RWA...)')
    )
    .addStringOption(o => o.setName('note').setDescription('Internal notes (optional)')),

  async execute(interaction) {
    const adminRoleId = process.env.ADMIN_ROLE_ID;
    const isAdmin = adminRoleId
      ? interaction.member.roles.cache.has(adminRoleId)
      : interaction.member.permissions.has('Administrator');

    if (!isAdmin) {
      return interaction.reply({ embeds: [embeds.error('Unauthorized', 'Only team members can onboard clients.')], ephemeral: true });
    }

    const user = interaction.options.getUser('user');
    const company = interaction.options.getString('company');
    const pkg = interaction.options.getString('package');
    const niche = interaction.options.getString('niche') || 'N/A';
    const note = interaction.options.getString('note') || null;

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    // Assign client role
    const clientRoleId = process.env.CLIENT_ROLE_ID;
    if (clientRoleId && member) {
      const role = interaction.guild.roles.cache.get(clientRoleId);
      if (role) await member.roles.add(role).catch(() => {});
    }

    // Save to db
    const existing = db.getClient(user.id);
    if (!existing) {
      db.addClient({
        userId: user.id,
        username: user.tag,
        company,
        package: pkg,
        niche,
        note,
        onboardedBy: interaction.user.tag,
      });
    }

    // DM the client
    try {
      await user.send({
        embeds: [
          embeds.info(
            '🎉 Welcome to Denora!',
            `Hi **${user.username}**!\n\nYou've been officially onboarded as a Denora client on the **${pkg}** package.\n\n` +
            `Our team will be in touch to kick off your campaign. In the meantime, feel free to open a ticket in the server if you have any questions.\n\n` +
            `— The Denora Team`
          )
        ],
      });
    } catch {
      // DMs may be disabled — not a critical failure
    }

    await interaction.reply({
      embeds: [embeds.clientOnboard(user, company, pkg)
        .addFields(
          { name: 'Niche', value: niche, inline: true },
          ...(note ? [{ name: 'Internal Note', value: note, inline: false }] : [])
        )],
      ephemeral: false,
    });
  },
};
