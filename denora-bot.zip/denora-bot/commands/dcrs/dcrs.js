const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { embeds, COLORS } = require('../../utils/embeds');
const db = require('../../utils/db');
const {
  LEVELS, ROLES, SCORE_WEIGHTS,
  levelFromFollowers, calcScore, scoreGrade,
  creatorTag, scoreBar, buildCampaignStack,
} = require('../../utils/dcrs');

// ── Admin guard ───────────────────────────────────────────────────────────────
function isAdmin(interaction) {
  const id = process.env.ADMIN_ROLE_ID;
  return id ? interaction.member.roles.cache.has(id) : interaction.member.permissions.has('Administrator');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dcrs')
    .setDescription('Denora Creator Ranking System')

    // ── /dcrs score ──────────────────────────────────────────────────────────
    .addSubcommand(s => s
      .setName('score')
      .setDescription('Score a creator across all 5 DCRS dimensions')
      .addStringOption(o => o.setName('name').setDescription('Creator name').setRequired(true))
      .addIntegerOption(o => o.setName('engagement').setDescription('Engagement rate score /30').setRequired(true).setMinValue(0).setMaxValue(30))
      .addIntegerOption(o => o.setName('quality').setDescription('Content quality score /20').setRequired(true).setMinValue(0).setMaxValue(20))
      .addIntegerOption(o => o.setName('niche').setDescription('Niche relevance score /20').setRequired(true).setMinValue(0).setMaxValue(20))
      .addIntegerOption(o => o.setName('consistency').setDescription('Posting consistency score /15').setRequired(true).setMinValue(0).setMaxValue(15))
      .addIntegerOption(o => o.setName('conversion').setDescription('Conversion ability score /15').setRequired(true).setMinValue(0).setMaxValue(15)))

    // ── /dcrs profile ────────────────────────────────────────────────────────
    .addSubcommand(s => s
      .setName('profile')
      .setDescription('View full DCRS profile for a creator')
      .addStringOption(o => o.setName('name').setDescription('Creator name').setRequired(true)))

    // ── /dcrs list ───────────────────────────────────────────────────────────
    .addSubcommand(s => s
      .setName('list')
      .setDescription('List creators — filter by level, role, or verification')
      .addIntegerOption(o => o.setName('level').setDescription('Filter by level (0–5)')
        .addChoices({name:'D0 Observer',value:0},{name:'D1 Nano',value:1},{name:'D2 Micro',value:2},{name:'D3 Mid-Tier',value:3},{name:'D4 Macro',value:4},{name:'D5 Mega',value:5}))
      .addStringOption(o => o.setName('role').setDescription('Filter by role')
        .addChoices({name:'Educator',value:'educator'},{name:'Entertainer',value:'entertainer'},{name:'Analyst',value:'analyst'},{name:'Community Driver',value:'community'}))
      .addBooleanOption(o => o.setName('verified').setDescription('Show only Denora Verified creators')))

    // ── /dcrs top ────────────────────────────────────────────────────────────
    .addSubcommand(s => s
      .setName('top')
      .setDescription('Top 10 creators by DCRS score'))

    // ── /dcrs verify ─────────────────────────────────────────────────────────
    .addSubcommand(s => s
      .setName('verify')
      .setDescription('Award Denora Verified (DV) status to a creator (score 80+ required)')
      .addStringOption(o => o.setName('name').setDescription('Creator name').setRequired(true)))

    // ── /dcrs setlevel ───────────────────────────────────────────────────────
    .addSubcommand(s => s
      .setName('setlevel')
      .setDescription('Manually set or override creator level')
      .addStringOption(o => o.setName('name').setDescription('Creator name').setRequired(true))
      .addIntegerOption(o => o.setName('level').setDescription('Level 0–5').setRequired(true).setMinValue(0).setMaxValue(5)))

    // ── /dcrs setrole ────────────────────────────────────────────────────────
    .addSubcommand(s => s
      .setName('setrole')
      .setDescription('Set creator primary role')
      .addStringOption(o => o.setName('name').setDescription('Creator name').setRequired(true))
      .addStringOption(o => o.setName('role').setDescription('Creator role').setRequired(true)
        .addChoices({name:'🧵 Educator',value:'educator'},{name:'🎥 Entertainer',value:'entertainer'},{name:'📊 Analyst',value:'analyst'},{name:'🧑‍🤝‍🧑 Community Driver',value:'community'})))

    // ── /dcrs stack ──────────────────────────────────────────────────────────
    .addSubcommand(s => s
      .setName('stack')
      .setDescription('Build a campaign creator stack recommendation')
      .addStringOption(o => o.setName('goal').setDescription('Campaign goal').setRequired(true)
        .addChoices({name:'🚀 Product Launch',value:'launch'},{name:'📣 Awareness',value:'awareness'},{name:'🏘️ Community Growth',value:'community'},{name:'💎 DeFi Protocol',value:'defi'}))
      .addIntegerOption(o => o.setName('budget').setDescription('Total campaign budget in USD (optional)')))

    // ── /dcrs evaluate ───────────────────────────────────────────────────────
    .addSubcommand(s => s
      .setName('evaluate')
      .setDescription('Run onboarding evaluation template for a new creator applicant')
      .addStringOption(o => o.setName('name').setDescription('Creator name').setRequired(true))
      .addStringOption(o => o.setName('handle').setDescription('Social handle').setRequired(true))
      .addStringOption(o => o.setName('followers').setDescription('Follower count e.g. 45K, 1.2M').setRequired(true))
      .addStringOption(o => o.setName('platform').setDescription('Primary platform').setRequired(true)
        .addChoices({name:'Twitter/X',value:'Twitter/X'},{name:'YouTube',value:'YouTube'},{name:'TikTok',value:'TikTok'},{name:'Telegram',value:'Telegram'},{name:'Instagram',value:'Instagram'}))
      .addStringOption(o => o.setName('niche').setDescription('Content niche e.g. DeFi, GameFi, NFT'))
      .addStringOption(o => o.setName('role').setDescription('Suggested role')
        .addChoices({name:'🧵 Educator',value:'educator'},{name:'🎥 Entertainer',value:'entertainer'},{name:'📊 Analyst',value:'analyst'},{name:'🧑‍🤝‍🧑 Community Driver',value:'community'}))),

  async execute(interaction) {
    if (!isAdmin(interaction)) {
      return interaction.reply({ embeds: [embeds.error('Unauthorized', 'Only team members can use DCRS commands.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    // ──────────────────────────────────────────────────────────────────────────
    // /dcrs score
    // ──────────────────────────────────────────────────────────────────────────
    if (sub === 'score') {
      const name       = interaction.options.getString('name');
      const kol        = db.getKOL(name);
      if (!kol) return interaction.reply({ embeds: [embeds.error('Not Found', `No creator named **${name}** on the roster. Add them first with \`/kol add\`.`)], ephemeral: true });

      const dimensions = {
        engagement:  interaction.options.getInteger('engagement'),
        quality:     interaction.options.getInteger('quality'),
        niche:       interaction.options.getInteger('niche'),
        consistency: interaction.options.getInteger('consistency'),
        conversion:  interaction.options.getInteger('conversion'),
      };

      const result = db.scoreKOL(name, dimensions);
      const { grade, color } = scoreGrade(result.total);
      const updated = db.getKOL(name);
      const tag = creatorTag(updated);

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle(`📊 DCRS Score — ${name}`)
        .setDescription(`**Creator Tag:** \`${tag}\``)
        .addFields(
          { name: '🔵 Engagement /30',    value: scoreBar(dimensions.engagement,  30), inline: false },
          { name: '🟣 Content Quality /20',value: scoreBar(dimensions.quality,     20), inline: false },
          { name: '🟢 Niche Relevance /20',value: scoreBar(dimensions.niche,       20), inline: false },
          { name: '🟡 Consistency /15',    value: scoreBar(dimensions.consistency, 15), inline: false },
          { name: '🔴 Conversion /15',     value: scoreBar(dimensions.conversion,  15), inline: false },
          { name: '━━━━━━━━━━━━━━━━━━━━━━', value: `**Total Score: ${result.total}/100 — Grade ${grade}**${result.total >= 80 ? '\n⭐ This creator is eligible for **Denora Verified**. Use `/dcrs verify`.' : ''}`, inline: false },
        )
        .setFooter({ text: 'Denora Creator Ranking System' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // /dcrs profile
    // ──────────────────────────────────────────────────────────────────────────
    if (sub === 'profile') {
      const name = interaction.options.getString('name');
      const kol  = db.getKOL(name);
      if (!kol) return interaction.reply({ embeds: [embeds.error('Not Found', `No creator named **${name}** found.`)], ephemeral: true });

      const level   = LEVELS[kol.level ?? 0];
      const role    = ROLES[kol.role]  || { label: 'Unassigned', emoji: '❓', desc: 'No role assigned' };
      const score   = kol.score ?? 0;
      const { grade, color } = scoreGrade(score);
      const scores  = kol.scores || {};

      const embed = new EmbedBuilder()
        .setColor(color)
        .setTitle(`${level.emoji} ${kol.verified ? '⭐ ' : ''}${name} — DCRS Profile`)
        .setDescription(`\`\`\`${creatorTag(kol)}\`\`\``)
        .addFields(
          { name: 'Level',       value: `**${level.tag}** — ${level.name} (${level.range})`, inline: true },
          { name: 'Role',        value: `${role.emoji} ${role.label}`, inline: true },
          { name: 'Score',       value: `**${score}/100** (${grade})`, inline: true },
          { name: 'Status',      value: level.status, inline: true },
          { name: 'Budget Range',value: level.budget, inline: true },
          { name: 'DV Status',   value: kol.verified ? '⭐ Denora Verified' : 'Not Verified', inline: true },
          { name: 'Platform',    value: kol.platform || 'N/A', inline: true },
          { name: 'Handle',      value: kol.handle   || 'N/A', inline: true },
          { name: 'Niche',       value: kol.niche    || 'N/A', inline: true },
          { name: 'Score Breakdown', value: scores.engagement != null
            ? [
                `Engagement:  ${scoreBar(scores.engagement,  30)}`,
                `Quality:     ${scoreBar(scores.quality,     20)}`,
                `Niche:       ${scoreBar(scores.niche,       20)}`,
                `Consistency: ${scoreBar(scores.consistency, 15)}`,
                `Conversion:  ${scoreBar(scores.conversion,  15)}`,
              ].join('\n')
            : 'Not yet scored — use `/dcrs score`',
            inline: false,
          },
          { name: 'Campaign',    value: kol.campaign || 'Unassigned', inline: true },
          { name: 'Payment',     value: kol.paymentStatus || 'Unpaid', inline: true },
        )
        .setFooter({ text: 'Denora Creator Ranking System' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // /dcrs list
    // ──────────────────────────────────────────────────────────────────────────
    if (sub === 'list') {
      const levelFilter    = interaction.options.getInteger('level');
      const roleFilter     = interaction.options.getString('role');
      const verifiedFilter = interaction.options.getBoolean('verified');

      let kols = db.getKOLs();
      if (levelFilter    != null)    kols = kols.filter(k => k.level === levelFilter);
      if (roleFilter     != null)    kols = kols.filter(k => k.role  === roleFilter);
      if (verifiedFilter === true)   kols = kols.filter(k => k.verified);

      kols.sort((a, b) => (b.score || 0) - (a.score || 0));

      if (!kols.length) {
        return interaction.reply({ embeds: [embeds.info('No Results', 'No creators match those filters.')], ephemeral: true });
      }

      const lines = kols.slice(0, 20).map((k, i) => {
        const level = LEVELS[k.level ?? 0];
        const role  = ROLES[k.role] || { emoji: '❓', label: 'Unassigned' };
        const score = k.score ?? '–';
        const dv    = k.verified ? ' ⭐' : '';
        return `\`${String(i+1).padStart(2)}\` ${level.emoji} **${k.name}** — \`${level.tag} ${role.label}\` — Score **${score}**${dv}`;
      });

      const filterLabel = [
        levelFilter != null ? `Level D${levelFilter}` : null,
        roleFilter  ? ROLES[roleFilter]?.label : null,
        verifiedFilter ? 'Verified Only' : null,
      ].filter(Boolean).join(', ') || 'All Creators';

      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x0a0aff)
            .setTitle(`📋 DCRS Roster — ${filterLabel} (${kols.length})`)
            .setDescription(lines.join('\n'))
            .setFooter({ text: 'Sorted by Score — Denora Creator Ranking System' })
            .setTimestamp(),
        ],
      });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // /dcrs top
    // ──────────────────────────────────────────────────────────────────────────
    if (sub === 'top') {
      const top = db.getTopKOLs(10);
      if (!top.length) return interaction.reply({ embeds: [embeds.info('Empty Roster', 'No creators on the roster yet.')], ephemeral: true });

      const medals = ['🥇','🥈','🥉'];
      const lines = top.map((k, i) => {
        const level = LEVELS[k.level ?? 0];
        const role  = ROLES[k.role] || { label: 'Unassigned' };
        const medal = medals[i] || `\`${i+1} \``;
        const dv    = k.verified ? ' ⭐' : '';
        return `${medal} **${k.name}** — \`${level.tag} ${role.label}\` — **${k.score ?? 0}/100**${dv}`;
      });

      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xFFD700)
            .setTitle('🏆 DCRS Top 10 — Denora Creator Leaderboard')
            .setDescription(lines.join('\n'))
            .setFooter({ text: 'Denora Creator Ranking System' })
            .setTimestamp(),
        ],
      });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // /dcrs verify
    // ──────────────────────────────────────────────────────────────────────────
    if (sub === 'verify') {
      const name   = interaction.options.getString('name');
      const result = db.verifyKOL(name, interaction.user.tag);

      if (result === false)           return interaction.reply({ embeds: [embeds.error('Not Found', `No creator named **${name}** found.`)], ephemeral: true });
      if (result === 'score_too_low') return interaction.reply({ embeds: [embeds.error('Score Too Low', `**${name}** needs a DCRS score of **80+** to receive Denora Verified status. Score them first with \`/dcrs score\`.`)], ephemeral: true });

      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0xFFD700)
            .setTitle('⭐ Denora Verified — Awarded!')
            .setDescription(`**${name}** has been awarded **Denora Verified (DV)** status.\n\nThey are now a premium Denora creator — charge clients a higher rate for DV creators.`)
            .setFooter({ text: `Verified by ${interaction.user.tag}` })
            .setTimestamp(),
        ],
      });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // /dcrs setlevel
    // ──────────────────────────────────────────────────────────────────────────
    if (sub === 'setlevel') {
      const name  = interaction.options.getString('name');
      const level = interaction.options.getInteger('level');
      const ok    = db.updateKOL(name, { level });
      if (!ok) return interaction.reply({ embeds: [embeds.error('Not Found', `No creator named **${name}** found.`)], ephemeral: true });
      const lv = LEVELS[level];
      return interaction.reply({ embeds: [embeds.success('Level Updated', `**${name}** is now **${lv.tag} — ${lv.name}** (${lv.range})\nStatus: ${lv.status}`)] });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // /dcrs setrole
    // ──────────────────────────────────────────────────────────────────────────
    if (sub === 'setrole') {
      const name = interaction.options.getString('name');
      const role = interaction.options.getString('role');
      const ok   = db.updateKOL(name, { role });
      if (!ok) return interaction.reply({ embeds: [embeds.error('Not Found', `No creator named **${name}** found.`)], ephemeral: true });
      const r = ROLES[role];
      return interaction.reply({ embeds: [embeds.success('Role Updated', `**${name}** is now tagged as **${r.emoji} ${r.label}**\n${r.desc}`)] });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // /dcrs stack
    // ──────────────────────────────────────────────────────────────────────────
    if (sub === 'stack') {
      const goal   = interaction.options.getString('goal');
      const budget = interaction.options.getInteger('budget') || 0;
      const stack  = buildCampaignStack(goal, budget);

      const goalLabels = { launch: '🚀 Product Launch', awareness: '📣 Awareness', community: '🏘️ Community Growth', defi: '💎 DeFi Protocol' };
      const totalCreators = stack.reduce((a, t) => a + t.count, 0);

      const lines = stack.map(t => {
        const budgetLine = budget ? ` — ~$${t.perHead}/ea ($${t.allocated} allocated)` : ` — Budget: ${t.level.budget}`;
        return [
          `${t.level.emoji} **${t.count}× ${t.level.tag} ${t.role.emoji} ${t.role.label}**`,
          `┗ ${t.purpose}${budgetLine}`,
        ].join('\n');
      });

      const embed = new EmbedBuilder()
        .setColor(0x0a0aff)
        .setTitle(`🎯 Campaign Stack — ${goalLabels[goal]}`)
        .setDescription(
          (budget ? `**Budget:** $${budget.toLocaleString()} across **${totalCreators} creators**\n\n` : `**${totalCreators} creators** recommended\n\n`) +
          lines.join('\n\n')
        )
        .addFields({
          name: '💡 Denora Strategy Insight',
          value: budget
            ? `Instead of spending $${budget.toLocaleString()} on 1 macro influencer — deploy it strategically across ${totalCreators} creators at different levels for compounding reach and trust.`
            : 'A strategic multi-level stack always outperforms spending your entire budget on one big name. Depth wins in Web3.',
        })
        .setFooter({ text: 'Denora Creator Ranking System — Campaign Stack Builder' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }

    // ──────────────────────────────────────────────────────────────────────────
    // /dcrs evaluate
    // ──────────────────────────────────────────────────────────────────────────
    if (sub === 'evaluate') {
      const name      = interaction.options.getString('name');
      const handle    = interaction.options.getString('handle');
      const followers = interaction.options.getString('followers');
      const platform  = interaction.options.getString('platform');
      const niche     = interaction.options.getString('niche') || 'General Web3';
      const role      = interaction.options.getString('role');

      // Auto-determine level from followers
      const levelIdx = levelFromFollowers(followers);
      const level    = LEVELS[levelIdx];
      const roleObj  = role ? ROLES[role] : null;

      // Check if already on roster
      const existing = db.getKOL(name);
      if (!existing) {
        // Auto-add to roster with basic info
        db.addKOL({
          name, handle, platform, niche,
          reach: followers,
          level: levelIdx,
          role: role || null,
          campaign: null,
          paymentStatus: 'Unpaid',
          deliverables: [],
          payments: [],
          addedBy: interaction.user.tag,
          source: 'Evaluated via /dcrs evaluate',
        });
      } else {
        db.updateKOL(name, { level: levelIdx, role: role || existing.role });
      }

      const embed = new EmbedBuilder()
        .setColor(0x0a0aff)
        .setTitle(`📋 Creator Evaluation — ${name}`)
        .setDescription(`Applicant has been ${existing ? 'updated in' : 'added to'} the Denora roster.\n**Next step:** Score them with \`/dcrs score ${name}\``)
        .addFields(
          { name: 'Handle',      value: handle,   inline: true },
          { name: 'Platform',    value: platform,  inline: true },
          { name: 'Followers',   value: followers, inline: true },
          { name: 'Auto Level',  value: `${level.emoji} **${level.tag} — ${level.name}**`, inline: true },
          { name: 'Role Tagged', value: roleObj ? `${roleObj.emoji} ${roleObj.label}` : '⏳ Pending — assign with `/dcrs setrole`', inline: true },
          { name: 'Niche',       value: niche,     inline: true },
          { name: 'Budget Range',value: level.budget, inline: true },
          { name: 'Status',      value: level.status, inline: true },
          { name: '⏳ Pending Actions', value:
            `□ Review content samples\n□ Score with \`/dcrs score ${name}\`\n□ Assign to campaign if approved\n□ Award DV if score ≥ 80`,
            inline: false,
          },
        )
        .setFooter({ text: `Evaluated by ${interaction.user.tag} — Denora DCRS` })
        .setTimestamp();

      return interaction.reply({ embeds: [embed] });
    }
  },
};
