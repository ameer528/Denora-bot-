const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require('discord.js');
const { embeds } = require('../../utils/embeds');
const db = require('../../utils/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ticket system')
    .addSubcommand(sub =>
      sub.setName('open')
        .setDescription('Open a new support ticket')
        .addStringOption(opt =>
          opt.setName('reason').setDescription('Reason for your ticket').setRequired(true)))
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all open tickets (Admin only)')),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    // ── /ticket open ─────────────────────────────────────────────────────────
    if (sub === 'open') {
      const reason = interaction.options.getString('reason');
      const allTickets = db.getTickets();
      const ticketNum = allTickets.length + 1;

      // Create private thread
      let thread;
      try {
        thread = await interaction.channel.threads.create({
          name: `ticket-${ticketNum}-${interaction.user.username}`,
          autoArchiveDuration: 1440,
          type: ChannelType.PrivateThread,
          reason: `Ticket opened by ${interaction.user.tag}`,
        });
      } catch {
        // Fallback: some servers require the channel to support private threads
        thread = await interaction.channel.threads.create({
          name: `ticket-${ticketNum}-${interaction.user.username}`,
          autoArchiveDuration: 1440,
          reason: `Ticket opened by ${interaction.user.tag}`,
        });
      }

      // Add user to thread
      await thread.members.add(interaction.user.id);

      // Add admins to thread
      const adminRoleId = process.env.ADMIN_ROLE_ID;
      if (adminRoleId) {
        const adminRole = interaction.guild.roles.cache.get(adminRoleId);
        if (adminRole) {
          for (const [, member] of adminRole.members) {
            await thread.members.add(member.id).catch(() => {});
          }
        }
      }

      // Build close button
      const closeBtn = new ButtonBuilder()
        .setCustomId('close_ticket')
        .setLabel('Close Ticket')
        .setStyle(ButtonStyle.Danger)
        .setEmoji('🔒');

      const row = new ActionRowBuilder().addComponents(closeBtn);

      // Post ticket embed inside the thread
      await thread.send({
        embeds: [embeds.ticketOpened(interaction.user, reason, ticketNum)],
        components: [row],
      });

      // Save to db
      db.addTicket({
        ticketNum,
        threadId: thread.id,
        userId: interaction.user.id,
        username: interaction.user.tag,
        reason,
        status: 'open',
      });

      await interaction.reply({
        embeds: [embeds.success('Ticket Opened', `Your ticket has been created → ${thread}`)],
        ephemeral: true,
      });
    }

    // ── /ticket list ─────────────────────────────────────────────────────────
    if (sub === 'list') {
      const adminRoleId = process.env.ADMIN_ROLE_ID;
      const isAdmin = adminRoleId
        ? interaction.member.roles.cache.has(adminRoleId)
        : interaction.member.permissions.has('Administrator');

      if (!isAdmin) {
        return interaction.reply({ embeds: [embeds.error('Unauthorized', 'Only admins can list tickets.')], ephemeral: true });
      }

      const tickets = db.getTickets().filter(t => t.status === 'open');
      if (!tickets.length) {
        return interaction.reply({ embeds: [embeds.info('No Open Tickets', 'All tickets are closed.')], ephemeral: true });
      }

      const list = tickets.map(t => `• **#${t.ticketNum}** — ${t.username} — _${t.reason}_`).join('\n');
      await interaction.reply({
        embeds: [embeds.info(`Open Tickets (${tickets.length})`, list)],
        ephemeral: true,
      });
    }
  },
};
