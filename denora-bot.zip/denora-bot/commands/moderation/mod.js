const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { embeds } = require('../../utils/embeds');
const db = require('../../utils/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mod')
    .setDescription('Moderation tools')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)

    .addSubcommand(sub =>
      sub.setName('warn')
        .setDescription('Warn a member')
        .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(true)))

    .addSubcommand(sub =>
      sub.setName('warnings')
        .setDescription('View warnings for a member')
        .addUserOption(o => o.setName('user').setDescription('User to look up').setRequired(true)))

    .addSubcommand(sub =>
      sub.setName('kick')
        .setDescription('Kick a member')
        .addUserOption(o => o.setName('user').setDescription('User to kick').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason')))

    .addSubcommand(sub =>
      sub.setName('ban')
        .setDescription('Ban a member')
        .addUserOption(o => o.setName('user').setDescription('User to ban').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason'))
        .addIntegerOption(o => o.setName('days').setDescription('Days of messages to delete (0-7)').setMinValue(0).setMaxValue(7))),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const target = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const modLogId = process.env.MOD_LOG_CHANNEL_ID;

    async function logMod(action) {
      if (!modLogId) return;
      const logChannel = interaction.guild.channels.cache.get(modLogId);
      if (logChannel) await logChannel.send({ embeds: [embeds.modLog(action, interaction.user, target, reason)] });
    }

    // ── warn ──────────────────────────────────────────────────────────────────
    if (sub === 'warn') {
      db.addWarning({ userId: target.id, username: target.tag, reason, moderator: interaction.user.tag, guildId: interaction.guildId });

      const warnings = db.getWarnings(target.id);
      try {
        await target.send({ embeds: [embeds.warning('You have been warned', `**Server:** ${interaction.guild.name}\n**Reason:** ${reason}\n**Total warnings:** ${warnings.length}`)] });
      } catch {}

      await logMod('Warn');
      await interaction.reply({ embeds: [embeds.warning('Member Warned', `${target.tag} has been warned.\n**Reason:** ${reason}\n**Total warnings:** ${warnings.length}`)], ephemeral: false });
    }

    // ── warnings ──────────────────────────────────────────────────────────────
    if (sub === 'warnings') {
      const warns = db.getWarnings(target.id);
      if (!warns.length) {
        return interaction.reply({ embeds: [embeds.info('No Warnings', `${target.tag} has no warnings on record.`)], ephemeral: true });
      }
      const list = warns.map((w, i) => `**${i + 1}.** ${w.reason} — by ${w.moderator} — <t:${Math.floor(new Date(w.createdAt).getTime() / 1000)}:R>`).join('\n');
      await interaction.reply({ embeds: [embeds.warning(`Warnings for ${target.tag} (${warns.length})`, list)], ephemeral: true });
    }

    // ── kick ──────────────────────────────────────────────────────────────────
    if (sub === 'kick') {
      if (!member) return interaction.reply({ embeds: [embeds.error('Not Found', 'That user is not in this server.')], ephemeral: true });
      if (!member.kickable) return interaction.reply({ embeds: [embeds.error('Cannot Kick', 'I do not have permission to kick this user.')], ephemeral: true });

      try { await target.send({ embeds: [embeds.danger?.('Kicked', `You were kicked from **${interaction.guild.name}**.\n**Reason:** ${reason}`)] }); } catch {}
      await member.kick(reason);
      await logMod('Kick');
      await interaction.reply({ embeds: [embeds.success('Member Kicked', `${target.tag} has been kicked.\n**Reason:** ${reason}`)], ephemeral: false });
    }

    // ── ban ───────────────────────────────────────────────────────────────────
    if (sub === 'ban') {
      if (!member && !target) return interaction.reply({ embeds: [embeds.error('Not Found', 'User not found.')], ephemeral: true });
      if (member && !member.bannable) return interaction.reply({ embeds: [embeds.error('Cannot Ban', 'I do not have permission to ban this user.')], ephemeral: true });

      const days = interaction.options.getInteger('days') ?? 0;
      try { await target.send({ embeds: [embeds.error('Banned', `You were banned from **${interaction.guild.name}**.\n**Reason:** ${reason}`)] }); } catch {}
      await interaction.guild.members.ban(target.id, { reason, deleteMessageDays: days });
      await logMod('Ban');
      await interaction.reply({ embeds: [embeds.success('Member Banned', `${target.tag} has been banned.\n**Reason:** ${reason}`)], ephemeral: false });
    }
  },
};
