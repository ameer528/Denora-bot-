const { SlashCommandBuilder } = require('discord.js');
const { embeds } = require('../../utils/embeds');
const db = require('../../utils/db');
const { LEVELS, ROLES } = require('../../utils/dcrs');

function isAdmin(interaction) {
  const id = process.env.ADMIN_ROLE_ID;
  return id ? interaction.member.roles.cache.has(id) : interaction.member.permissions.has('Administrator');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('report')
    .setDescription('Analytics & reporting')
    .addSubcommand(s => s.setName('kols').setDescription('KOL roster + DCRS summary'))
    .addSubcommand(s => s.setName('campaigns').setDescription('Campaign overview'))
    .addSubcommand(s => s.setName('clients').setDescription('Client roster summary'))
    .addSubcommand(s => s.setName('server').setDescription('Server stats snapshot'))
    .addSubcommand(s => s.setName('dcrs').setDescription('Full DCRS system health report')),

  async execute(interaction) {
    if (!isAdmin(interaction)) {
      return interaction.reply({ embeds: [embeds.error('Unauthorized', 'Only team members can run reports.')], ephemeral: true });
    }
    await interaction.deferReply();
    const sub = interaction.options.getSubcommand();

    if (sub === 'kols') {
      const kols = db.getKOLs();
      const byPlatform  = {};
      const byLevel     = { 0:0, 1:0, 2:0, 3:0, 4:0, 5:0 };
      const byRole      = {};
      let paid = 0, pending = 0, totalD = 0, completedD = 0, verified = 0;

      for (const k of kols) {
        byPlatform[k.platform || 'Unknown'] = (byPlatform[k.platform || 'Unknown'] || 0) + 1;
        byLevel[k.level ?? 0] = (byLevel[k.level ?? 0] || 0) + 1;
        byRole[k.role   || 'unassigned'] = (byRole[k.role || 'unassigned'] || 0) + 1;
        if (k.paymentStatus === 'Paid') paid++;
        else pending++;
        if (k.verified) verified++;
        totalD     += k.deliverables?.length || 0;
        completedD += k.deliverables?.filter(d => d.status === 'Completed').length || 0;
      }

      const avgScore = kols.length ? Math.round(kols.reduce((a,k)=>a+(k.score||0),0)/kols.length) : 0;
      const levelBreakdown = Object.entries(byLevel).map(([l,c]) => `D${l}: ${c}`).join(' · ');
      const roleBreakdown  = Object.entries(byRole).map(([r,c])  => `${ROLES[r]?.label || r}: ${c}`).join(' · ');

      await interaction.editReply({
        embeds: [embeds.report('KOL Roster Report', {
          'Total Creators':     kols.length,
          '⭐ DV Verified':    verified,
          'Avg DCRS Score':    `${avgScore}/100`,
          'Paid':              paid,
          'Payment Pending':   pending,
          'Total Deliverables':totalD,
          'Completed':         completedD,
        }).addFields(
          { name: 'Level Breakdown', value: levelBreakdown || 'None', inline: false },
          { name: 'Role Breakdown',  value: roleBreakdown  || 'None', inline: false },
        )],
      });
    }

    if (sub === 'dcrs') {
      const kols = db.getKOLs();
      const scored    = kols.filter(k => k.score != null);
      const verified  = kols.filter(k => k.verified);
      const eligible  = kols.filter(k => !k.verified && (k.score||0) >= 80);
      const scores    = scored.map(k => k.score);
      const avg       = scores.length ? Math.round(scores.reduce((a,b)=>a+b,0)/scores.length) : 0;
      const top       = db.getTopKOLs(3);

      const levelLines = Object.entries(LEVELS).map(([i, l]) => {
        const count = kols.filter(k => (k.level ?? 0) === parseInt(i)).length;
        return `${l.emoji} **${l.tag}** ${l.name}: **${count}** creators`;
      }).join('\n');

      const topLines = top.map((k, i) => {
        const medals = ['🥇','🥈','🥉'];
        return `${medals[i]} **${k.name}** — Score **${k.score}**${k.verified ? ' ⭐' : ''}`;
      }).join('\n') || 'No creators scored yet';

      await interaction.editReply({
        embeds: [
          embeds.report('DCRS System Report', {
            'Total on Roster':   kols.length,
            'Scored':            scored.length,
            'Avg Score':         `${avg}/100`,
            '⭐ DV Verified':    verified.length,
            'DV Eligible':       eligible.length,
            'Unscored':          kols.length - scored.length,
          })
          .addFields(
            { name: 'Level Distribution', value: levelLines  || 'None', inline: false },
            { name: 'Top Creators',        value: topLines,              inline: false },
            ...(eligible.length ? [{ name: `⭐ Ready for DV (${eligible.length})`, value: eligible.map(k=>`• ${k.name} — ${k.score}/100`).join('\n'), inline: false }] : []),
          ),
        ],
      });
    }

    if (sub === 'campaigns') {
      const campaigns = db.getCampaigns();
      const byStatus  = {};
      for (const c of campaigns) byStatus[c.status] = (byStatus[c.status] || 0) + 1;
      const totalKOLs = campaigns.reduce((a,c) => a + (c.kols?.length||0), 0);
      await interaction.editReply({ embeds: [embeds.report('Campaign Report', {
        'Total':     campaigns.length,
        'Active':    byStatus['Active']    || 0,
        'Planning':  byStatus['Planning']  || 0,
        'Completed': byStatus['Completed'] || 0,
        'Paused':    byStatus['Paused']    || 0,
        'Total KOLs':totalKOLs,
      })] });
    }

    if (sub === 'clients') {
      const clients  = db.getClients();
      const byPkg    = {};
      for (const c of clients) byPkg[c.package] = (byPkg[c.package]||0)+1;
      const pkgBreak = Object.entries(byPkg).map(([p,c])=>`${p}: ${c}`).join(' · ') || 'None';
      await interaction.editReply({ embeds: [embeds.report('Client Report', { 'Total Clients': clients.length }).addFields({ name: 'Package Breakdown', value: pkgBreak })] });
    }

    if (sub === 'server') {
      const guild = interaction.guild;
      await guild.members.fetch();
      const total  = guild.memberCount;
      const bots   = guild.members.cache.filter(m=>m.user.bot).size;
      const open   = db.getTickets().filter(t=>t.status==='open').length;
      await interaction.editReply({ embeds: [embeds.report('Server Stats', {
        'Members':       total,
        'Humans':        total-bots,
        'Bots':          bots,
        'Channels':      guild.channels.cache.size,
        'Roles':         guild.roles.cache.size,
        'Open Tickets':  open,
      })] });
    }
  },
};
