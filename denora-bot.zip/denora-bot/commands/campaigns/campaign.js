const { SlashCommandBuilder } = require('discord.js');
const { embeds } = require('../../utils/embeds');
const db = require('../../utils/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('campaign')
    .setDescription('Campaign tracking & management')

    // ── /campaign create ──────────────────────────────────────────────────────
    .addSubcommand(sub =>
      sub.setName('create')
        .setDescription('Create a new campaign')
        .addStringOption(o => o.setName('name').setDescription('Campaign name').setRequired(true))
        .addStringOption(o => o.setName('client').setDescription('Client name').setRequired(true))
        .addStringOption(o => o.setName('start').setDescription('Start date (e.g. 2025-01-01)').setRequired(true))
        .addStringOption(o => o.setName('end').setDescription('End date (e.g. 2025-01-31)').setRequired(true))
        .addStringOption(o => o.setName('budget').setDescription('Budget (e.g. $5,000)'))
        .addStringOption(o => o.setName('goal').setDescription('Campaign goal / KPI')))

    // ── /campaign update ──────────────────────────────────────────────────────
    .addSubcommand(sub =>
      sub.setName('update')
        .setDescription('Post an update to a campaign')
        .addStringOption(o => o.setName('name').setDescription('Campaign name').setRequired(true))
        .addStringOption(o => o.setName('text').setDescription('Update text').setRequired(true)))

    // ── /campaign status ──────────────────────────────────────────────────────
    .addSubcommand(sub =>
      sub.setName('status')
        .setDescription('View campaign status')
        .addStringOption(o => o.setName('name').setDescription('Campaign name').setRequired(true)))

    // ── /campaign setstatus ───────────────────────────────────────────────────
    .addSubcommand(sub =>
      sub.setName('setstatus')
        .setDescription('Change campaign status')
        .addStringOption(o => o.setName('name').setDescription('Campaign name').setRequired(true))
        .addStringOption(o => o.setName('status').setDescription('New status').setRequired(true)
          .addChoices(
            { name: 'Planning', value: 'Planning' },
            { name: 'Active', value: 'Active' },
            { name: 'Paused', value: 'Paused' },
            { name: 'Completed', value: 'Completed' },
            { name: 'Cancelled', value: 'Cancelled' },
          )))

    // ── /campaign list ────────────────────────────────────────────────────────
    .addSubcommand(sub =>
      sub.setName('list')
        .setDescription('List all campaigns')
        .addStringOption(o => o.setName('status').setDescription('Filter by status')
          .addChoices(
            { name: 'Active', value: 'Active' },
            { name: 'Planning', value: 'Planning' },
            { name: 'Completed', value: 'Completed' },
            { name: 'All', value: 'All' },
          ))),

  async execute(interaction) {
    // Admin-only guard
    const adminRoleId = process.env.ADMIN_ROLE_ID;
    const isAdmin = adminRoleId
      ? interaction.member.roles.cache.has(adminRoleId)
      : interaction.member.permissions.has('Administrator');

    if (!isAdmin) {
      return interaction.reply({ embeds: [embeds.error('Unauthorized', 'Only team members can manage campaigns.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    // ── create ────────────────────────────────────────────────────────────────
    if (sub === 'create') {
      const name = interaction.options.getString('name');
      if (db.getCampaign(name)) {
        return interaction.reply({ embeds: [embeds.warning('Already Exists', `A campaign named **${name}** already exists.`)], ephemeral: true });
      }
      db.addCampaign({
        name,
        client: interaction.options.getString('client'),
        startDate: interaction.options.getString('start'),
        endDate: interaction.options.getString('end'),
        budget: interaction.options.getString('budget') || 'TBD',
        goal: interaction.options.getString('goal') || 'TBD',
        status: 'Planning',
        createdBy: interaction.user.tag,
      });
      await interaction.reply({ embeds: [embeds.success('Campaign Created', `Campaign **${name}** has been created and is in Planning status.`)], ephemeral: false });
    }

    // ── update ────────────────────────────────────────────────────────────────
    if (sub === 'update') {
      const name = interaction.options.getString('name');
      const campaign = db.getCampaign(name);
      if (!campaign) {
        return interaction.reply({ embeds: [embeds.error('Not Found', `No campaign named **${name}** found.`)], ephemeral: true });
      }

      const updateEntry = {
        text: interaction.options.getString('text'),
        postedBy: interaction.user.tag,
        timestamp: new Date().toISOString(),
      };

      const updates = [...(campaign.updates || []), updateEntry];
      db.updateCampaign(name, { updates });

      await interaction.reply({
        embeds: [embeds.success('Update Posted', `Update logged for campaign **${name}**:\n> ${updateEntry.text}`)],
        ephemeral: false,
      });
    }

    // ── status ────────────────────────────────────────────────────────────────
    if (sub === 'status') {
      const name = interaction.options.getString('name');
      const campaign = db.getCampaign(name);
      if (!campaign) {
        return interaction.reply({ embeds: [embeds.error('Not Found', `No campaign named **${name}** found.`)], ephemeral: true });
      }
      await interaction.reply({ embeds: [embeds.campaignStatus(campaign)], ephemeral: false });
    }

    // ── setstatus ─────────────────────────────────────────────────────────────
    if (sub === 'setstatus') {
      const name = interaction.options.getString('name');
      const status = interaction.options.getString('status');
      const ok = db.updateCampaign(name, { status });
      if (!ok) {
        return interaction.reply({ embeds: [embeds.error('Not Found', `No campaign named **${name}** found.`)], ephemeral: true });
      }
      await interaction.reply({ embeds: [embeds.success('Status Updated', `Campaign **${name}** is now \`${status}\`.`)], ephemeral: false });
    }

    // ── list ──────────────────────────────────────────────────────────────────
    if (sub === 'list') {
      const filter = interaction.options.getString('status') || 'Active';
      let campaigns = db.getCampaigns();
      if (filter !== 'All') campaigns = campaigns.filter(c => c.status === filter);

      if (!campaigns.length) {
        return interaction.reply({ embeds: [embeds.info('No Campaigns', `No campaigns with status \`${filter}\`.`)], ephemeral: true });
      }

      const list = campaigns.map(c =>
        `• **${c.name}** — Client: ${c.client} — \`${c.status}\` — KOLs: ${c.kols?.length || 0}`
      ).join('\n');

      await interaction.reply({
        embeds: [embeds.info(`Campaigns (${campaigns.length}) — ${filter}`, list)],
        ephemeral: false,
      });
    }
  },
};
