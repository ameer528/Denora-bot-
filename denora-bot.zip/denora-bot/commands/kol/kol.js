const { SlashCommandBuilder } = require('discord.js');
const { embeds } = require('../../utils/embeds');
const db = require('../../utils/db');
const { LEVELS, ROLES, levelFromFollowers, creatorTag } = require('../../utils/dcrs');

function isAdmin(interaction) {
  const id = process.env.ADMIN_ROLE_ID;
  return id ? interaction.member.roles.cache.has(id) : interaction.member.permissions.has('Administrator');
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kol')
    .setDescription('KOL & talent management')

    .addSubcommand(s => s.setName('add').setDescription('Add a KOL to the roster')
      .addStringOption(o => o.setName('name').setDescription('Full name').setRequired(true))
      .addStringOption(o => o.setName('handle').setDescription('Social handle e.g. @username').setRequired(true))
      .addStringOption(o => o.setName('platform').setDescription('Primary platform').setRequired(true)
        .addChoices({name:'Twitter/X',value:'Twitter/X'},{name:'YouTube',value:'YouTube'},{name:'Telegram',value:'Telegram'},{name:'TikTok',value:'TikTok'},{name:'Instagram',value:'Instagram'},{name:'Other',value:'Other'}))
      .addStringOption(o => o.setName('followers').setDescription('Follower count e.g. 45K, 1.2M').setRequired(true))
      .addStringOption(o => o.setName('role').setDescription('Primary creator role').setRequired(true)
        .addChoices({name:'🧵 Educator',value:'educator'},{name:'🎥 Entertainer',value:'entertainer'},{name:'📊 Analyst',value:'analyst'},{name:'🧑‍🤝‍🧑 Community Driver',value:'community'}))
      .addStringOption(o => o.setName('niche').setDescription('Content niche e.g. DeFi, GameFi, NFT')))

    .addSubcommand(s => s.setName('remove').setDescription('Remove a KOL from the roster')
      .addStringOption(o => o.setName('name').setDescription('KOL name').setRequired(true)))

    .addSubcommand(s => s.setName('assign').setDescription('Assign a KOL to a campaign')
      .addStringOption(o => o.setName('name').setDescription('KOL name').setRequired(true))
      .addStringOption(o => o.setName('campaign').setDescription('Campaign name').setRequired(true)))

    .addSubcommand(s => s.setName('deliverable').setDescription('Log a KOL deliverable')
      .addStringOption(o => o.setName('name').setDescription('KOL name').setRequired(true))
      .addStringOption(o => o.setName('title').setDescription('Deliverable title').setRequired(true))
      .addStringOption(o => o.setName('status').setDescription('Status').setRequired(true)
        .addChoices({name:'Pending',value:'Pending'},{name:'In Progress',value:'In Progress'},{name:'Completed',value:'Completed'},{name:'Cancelled',value:'Cancelled'}))
      .addStringOption(o => o.setName('link').setDescription('Content link (optional)')))

    .addSubcommand(s => s.setName('payment').setDescription('Log a payment for a KOL')
      .addStringOption(o => o.setName('name').setDescription('KOL name').setRequired(true))
      .addStringOption(o => o.setName('amount').setDescription('Amount e.g. $500').setRequired(true))
      .addStringOption(o => o.setName('status').setDescription('Payment status').setRequired(true)
        .addChoices({name:'Paid',value:'Paid'},{name:'Pending',value:'Pending'},{name:'Partial',value:'Partial'}))
      .addStringOption(o => o.setName('note').setDescription('Note e.g. tx hash')))

    .addSubcommand(s => s.setName('info').setDescription('View a KOL profile')
      .addStringOption(o => o.setName('name').setDescription('KOL name').setRequired(true)))

    .addSubcommand(s => s.setName('list').setDescription('List all KOLs')
      .addStringOption(o => o.setName('campaign').setDescription('Filter by campaign (optional)'))),

  async execute(interaction) {
    if (!isAdmin(interaction)) {
      return interaction.reply({ embeds: [embeds.error('Unauthorized', 'Only team members can manage KOLs.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const name      = interaction.options.getString('name');
      const followers = interaction.options.getString('followers');
      const role      = interaction.options.getString('role');
      const levelIdx  = levelFromFollowers(followers);
      const level     = LEVELS[levelIdx];

      if (db.getKOL(name)) {
        return interaction.reply({ embeds: [embeds.warning('Already Exists', `**${name}** is already on the roster. Use \`/dcrs evaluate\` to update their profile.`)], ephemeral: true });
      }

      db.addKOL({
        name,
        handle:    interaction.options.getString('handle'),
        platform:  interaction.options.getString('platform'),
        niche:     interaction.options.getString('niche') || 'General',
        reach:     followers,
        level:     levelIdx,
        role,
        campaign:  null,
        paymentStatus: 'Unpaid',
        deliverables: [],
        payments: [],
        addedBy: interaction.user.tag,
      });

      const roleObj = ROLES[role];
      return interaction.reply({
        embeds: [
          embeds.success('KOL Added', `**${name}** added to the Denora roster.\n\n**DCRS Tag:** \`${level.tag} ${roleObj.label}\`\n**Level:** ${level.emoji} ${level.name} (${level.range})\n**Status:** ${level.status}\n**Budget Range:** ${level.budget}\n\n💡 Score them next with \`/dcrs score ${name}\``)
        ],
      });
    }

    if (sub === 'remove') {
      const name = interaction.options.getString('name');
      if (!db.getKOL(name)) return interaction.reply({ embeds: [embeds.error('Not Found', `No KOL named **${name}** on the roster.`)], ephemeral: true });
      db.removeKOL(name);
      return interaction.reply({ embeds: [embeds.success('KOL Removed', `**${name}** has been removed from the roster.`)] });
    }

    if (sub === 'assign') {
      const name     = interaction.options.getString('name');
      const campaign = interaction.options.getString('campaign');
      if (!db.getKOL(name))       return interaction.reply({ embeds: [embeds.error('Not Found', `No KOL named **${name}** found.`)], ephemeral: true });
      if (!db.getCampaign(campaign)) return interaction.reply({ embeds: [embeds.error('Campaign Not Found', `No campaign named **${campaign}** exists. Create it with \`/campaign create\`.`)], ephemeral: true });
      db.updateKOL(name, { campaign });
      const camp = db.getCampaign(campaign);
      const kols = camp.kols || [];
      if (!kols.includes(name)) db.updateCampaign(campaign, { kols: [...kols, name] });
      return interaction.reply({ embeds: [embeds.success('KOL Assigned', `**${name}** assigned to campaign **${campaign}**.`)] });
    }

    if (sub === 'deliverable') {
      const name = interaction.options.getString('name');
      const kol  = db.getKOL(name);
      if (!kol) return interaction.reply({ embeds: [embeds.error('Not Found', `No KOL named **${name}** found.`)], ephemeral: true });
      const deliverable = { title: interaction.options.getString('title'), status: interaction.options.getString('status'), link: interaction.options.getString('link') || null, loggedAt: new Date().toISOString(), loggedBy: interaction.user.tag };
      db.updateKOL(name, { deliverables: [...(kol.deliverables || []), deliverable] });
      return interaction.reply({ embeds: [embeds.success('Deliverable Logged', `**${deliverable.title}** → \`${deliverable.status}\` logged for **${name}**.`)] });
    }

    if (sub === 'payment') {
      const name = interaction.options.getString('name');
      const kol  = db.getKOL(name);
      if (!kol) return interaction.reply({ embeds: [embeds.error('Not Found', `No KOL named **${name}** found.`)], ephemeral: true });
      const payment = { amount: interaction.options.getString('amount'), status: interaction.options.getString('status'), note: interaction.options.getString('note') || null, loggedAt: new Date().toISOString(), loggedBy: interaction.user.tag };
      db.updateKOL(name, { payments: [...(kol.payments || []), payment], paymentStatus: payment.status });
      return interaction.reply({ embeds: [embeds.success('Payment Logged', `**${payment.amount}** (${payment.status}) logged for **${name}**.`)] });
    }

    if (sub === 'info') {
      const name = interaction.options.getString('name');
      const kol  = db.getKOL(name);
      if (!kol) return interaction.reply({ embeds: [embeds.error('Not Found', `No KOL named **${name}** on the roster.`)], ephemeral: true });
      return interaction.reply({ embeds: [embeds.kolProfile(kol)] });
    }

    if (sub === 'list') {
      const filterCampaign = interaction.options.getString('campaign');
      let kols = db.getKOLs();
      if (filterCampaign) kols = kols.filter(k => k.campaign?.toLowerCase() === filterCampaign.toLowerCase());
      if (!kols.length) return interaction.reply({ embeds: [embeds.info('No KOLs', 'The talent roster is empty.')], ephemeral: true });

      kols.sort((a, b) => (b.score || 0) - (a.score || 0));
      const list = kols.map(k => {
        const level = LEVELS[k.level ?? 0];
        const role  = ROLES[k.role] || { label: 'Unassigned' };
        const dv    = k.verified ? ' ⭐' : '';
        return `• ${level.emoji} **${k.name}** \`${level.tag} ${role.label}\` — Score: **${k.score ?? '–'}**${dv} — Payment: \`${k.paymentStatus}\``;
      }).join('\n');

      return interaction.reply({ embeds: [embeds.info(`KOL Roster (${kols.length})${filterCampaign ? ` — ${filterCampaign}` : ''}`, list)] });
    }
  },
};
