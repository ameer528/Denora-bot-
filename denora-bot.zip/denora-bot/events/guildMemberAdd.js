const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { embeds } = require('../utils/embeds');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    const channelId = process.env.WELCOME_CHANNEL_ID;
    if (!channelId) return;
    const channel = member.guild.channels.cache.get(channelId);
    if (!channel) return;

    // ── Role selection buttons ────────────────────────────────────────────────
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`role_creator_${member.id}`)
        .setLabel('🎨 Creator / KOL')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`role_client_${member.id}`)
        .setLabel('🚀 Client / Partner')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`role_community_${member.id}`)
        .setLabel('🌐 Community Member')
        .setStyle(ButtonStyle.Secondary),
    );

    const welcomeEmbed = embeds.welcome(member).setDescription(
      `Hey ${member}! Welcome to the **Denora** server.\n\n` +
      `We're a Web3 growth studio connecting creators, brands, and communities.\n\n` +
      `👇 **Who are you?** Pick a role below to get started.`
    );

    try {
      await channel.send({ embeds: [welcomeEmbed], components: [row] });
    } catch (err) {
      console.warn('[guildMemberAdd] Could not send welcome message:', err.message);
    }
  },
};
