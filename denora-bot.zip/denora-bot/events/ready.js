module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`✅ Denora Bot is online as ${client.user.tag}`);
    client.user.setPresence({
      activities: [{ name: 'Web3 Growth | /help', type: 3 }],
      status: 'online',
    });
  },
};
