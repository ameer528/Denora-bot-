const { AttachmentBuilder, EmbedBuilder } = require('discord.js');
const { embeds } = require('../utils/embeds');
const db = require('../utils/db');
// NOTE: creatorCard is NOT imported here at top level — it requires @napi-rs/canvas
// which may not be installed yet. It is lazy-loaded only when needed inside the handler.

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {

    // ── Slash Commands ────────────────────────────────────────────────────────
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      try {
        await command.execute(interaction, client);
      } catch (err) {
        console.error(`[Command Error] ${interaction.commandName}:`, err);
        const errEmbed = embeds.error('Something went wrong', `\`\`\`${err.message}\`\`\``);
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp({ embeds: [errEmbed], ephemeral: true });
        } else {
          await interaction.reply({ embeds: [errEmbed], ephemeral: true });
        }
      }
      return;
    }

    // ── Button Interactions ───────────────────────────────────────────────────
    if (interaction.isButton()) {

      // ── Close Ticket ────────────────────────────────────────────────────────
      if (interaction.customId === 'close_ticket') {
        const thread = interaction.channel;
        if (!thread?.isThread()) return;
        await interaction.reply({ content: '🔒 Closing ticket in 5 seconds...', ephemeral: false });
        db.closeTicket(thread.id);
        setTimeout(async () => {
          try { await thread.setArchived(true); await thread.setLocked(true); } catch {}
        }, 5000);
        return;
      }

      // ── Role Selection Buttons ────────────────────────────────────────────
      const isCreator   = interaction.customId.startsWith('role_creator_');
      const isClient    = interaction.customId.startsWith('role_client_');
      const isCommunity = interaction.customId.startsWith('role_community_');

      if (isCreator || isClient || isCommunity) {
        const targetUserId = interaction.customId.split('_').pop();
        if (interaction.user.id !== targetUserId) {
          return interaction.reply({ content: '❌ This button is not for you.', ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: false });

        const guild  = interaction.guild;
        const member = await guild.members.fetch(interaction.user.id).catch(() => null);
        const roleType = isCreator ? 'creator' : isClient ? 'client' : 'community';

        // Assign Discord role
        const roleMap = {
          creator:   process.env.KOL_ROLE_ID,
          client:    process.env.CLIENT_ROLE_ID,
          community: process.env.COMMUNITY_ROLE_ID || process.env.TEAM_ROLE_ID,
        };
        const discordRoleId = roleMap[roleType];
        if (discordRoleId && member) {
          const discordRole = guild.roles.cache.get(discordRoleId);
          if (discordRole) await member.roles.add(discordRole).catch(() => {});
        }

        // ── Creator Card ──────────────────────────────────────────────────────
        if (isCreator) {
          try {
            // Lazy-load canvas module — only fails if npm install hasn't been run
            let generateCreatorCard;
            try {
              ({ generateCreatorCard } = require('../utils/creatorCard'));
            } catch (canvasErr) {
              console.warn('[Creator Card] @napi-rs/canvas not installed:', canvasErr.message);
              return interaction.editReply({
                content: `✅ Welcome to the Denora Creator Network, ${interaction.user}! Your role has been assigned.\n\n*Creator card generation unavailable — run \`npm install\` on the bot server to enable it.*`,
              });
            }

            const avatarUrl = interaction.user.displayAvatarURL({ extension: 'png', size: 256, forceStatic: true });
            const username  = interaction.member?.displayName || interaction.user.username;
            const cardBuffer = await generateCreatorCard(avatarUrl, username);
            const attachment = new AttachmentBuilder(cardBuffer, { name: 'creator-card.png' });

            const cardEmbed = new EmbedBuilder()
              .setColor(0x0a0aff)
              .setTitle('🎨 Welcome to the Creator Corner!')
              .setDescription(
                `You're officially part of the **Denora Creator Network**, ${interaction.user}! 🚀\n\n` +
                `Your creator card is ready. Here's what to do:\n\n` +
                `📥 **Save** your card (right-click → Save Image)\n` +
                `🐦 **Post it on X** and tag us → \`@DenorGrowth\`\n` +
                `💬 Use the caption below ↓`
              )
              .addFields({
                name: '📋 Ready-to-Post Caption',
                value:
                  '```\n' +
                  'Just joined the @DenorGrowth Creator Network! 🚀\n\n' +
                  'Building in Web3 and growing my reach 🌐\n\n' +
                  '#Web3 #Creator #Denora #KOL #BuildingInPublic' +
                  '\n```',
              })
              .setImage('attachment://creator-card.png')
              .setFooter({ text: 'Denora • 1st Web3 Growth Studio' })
              .setTimestamp();

            await interaction.editReply({ embeds: [cardEmbed], files: [attachment] });

          } catch (err) {
            console.error('[Creator Card Error]', err);
            await interaction.editReply({
              content: `✅ Welcome to the Denora Creator Network, ${interaction.user}! Your role has been assigned.`,
            });
          }
          return;
        }

        // ── Client / Community ────────────────────────────────────────────────
        const labelMap = { client: 'Client / Partner 🚀', community: 'Community Member 🌐' };
        await interaction.editReply({
          embeds: [
            embeds.success(
              `Role Assigned — ${labelMap[roleType]}`,
              `Welcome to Denora, ${interaction.user}! 🎉\n\nYour role is set. Explore the server or open a ticket with \`/ticket open\` anytime.`
            ),
          ],
        });
      }
    }
  },
};
