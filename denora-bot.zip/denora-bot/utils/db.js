const fs   = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const FILES = {
  kols:      path.join(DATA_DIR, 'kols.json'),
  campaigns: path.join(DATA_DIR, 'campaigns.json'),
  tickets:   path.join(DATA_DIR, 'tickets.json'),
  clients:   path.join(DATA_DIR, 'clients.json'),
  warnings:  path.join(DATA_DIR, 'warnings.json'),
};

for (const [, fp] of Object.entries(FILES)) {
  if (!fs.existsSync(fp)) fs.writeFileSync(fp, JSON.stringify([], null, 2));
}

function read(store)       { try { return JSON.parse(fs.readFileSync(FILES[store], 'utf8')); } catch { return []; } }
function write(store, data){ fs.writeFileSync(FILES[store], JSON.stringify(data, null, 2)); }

const db = {
  // ── KOLs / Creators ──────────────────────────────────────────────────────
  getKOLs:  ()     => read('kols'),
  getKOL:   (name) => read('kols').find(k => k.name.toLowerCase() === name.toLowerCase()),

  addKOL: (kol) => {
    const data = read('kols');
    data.push({ ...kol, id: Date.now().toString(), createdAt: new Date().toISOString() });
    write('kols', data);
  },

  removeKOL: (name) => {
    write('kols', read('kols').filter(k => k.name.toLowerCase() !== name.toLowerCase()));
  },

  updateKOL: (name, updates) => {
    const data = read('kols');
    const idx  = data.findIndex(k => k.name.toLowerCase() === name.toLowerCase());
    if (idx === -1) return false;
    data[idx] = { ...data[idx], ...updates, updatedAt: new Date().toISOString() };
    write('kols', data);
    return true;
  },

  // DCRS — update score dimensions and recalculate total
  scoreKOL: (name, dimensions) => {
    const { calcScore } = require('./dcrs');
    const data = read('kols');
    const idx  = data.findIndex(k => k.name.toLowerCase() === name.toLowerCase());
    if (idx === -1) return false;
    const scores = { ...(data[idx].scores || {}), ...dimensions };
    const total  = calcScore(scores);
    data[idx] = { ...data[idx], scores, score: total, updatedAt: new Date().toISOString() };
    // Auto-award DV if score >= 80 and proven conversions
    if (total >= 80) data[idx].verifiedEligible = true;
    write('kols', data);
    return { scores, total };
  },

  verifyKOL: (name, by) => {
    const data = read('kols');
    const idx  = data.findIndex(k => k.name.toLowerCase() === name.toLowerCase());
    if (idx === -1) return false;
    if ((data[idx].score || 0) < 80) return 'score_too_low';
    data[idx].verified  = true;
    data[idx].verifiedBy= by;
    data[idx].verifiedAt= new Date().toISOString();
    write('kols', data);
    return true;
  },

  // Filter helpers
  getKOLsByLevel:  (level)  => read('kols').filter(k => k.level === level),
  getKOLsByRole:   (role)   => read('kols').filter(k => k.role  === role),
  getVerifiedKOLs: ()       => read('kols').filter(k => k.verified),
  getTopKOLs:      (n = 10) => read('kols').sort((a,b) => (b.score||0) - (a.score||0)).slice(0, n),

  // ── Campaigns ─────────────────────────────────────────────────────────────
  getCampaigns:  ()     => read('campaigns'),
  getCampaign:   (name) => read('campaigns').find(c => c.name.toLowerCase() === name.toLowerCase()),

  addCampaign: (campaign) => {
    const data = read('campaigns');
    data.push({ ...campaign, id: Date.now().toString(), createdAt: new Date().toISOString(), kols: [], updates: [] });
    write('campaigns', data);
  },

  updateCampaign: (name, updates) => {
    const data = read('campaigns');
    const idx  = data.findIndex(c => c.name.toLowerCase() === name.toLowerCase());
    if (idx === -1) return false;
    data[idx] = { ...data[idx], ...updates, updatedAt: new Date().toISOString() };
    write('campaigns', data);
    return true;
  },

  // ── Tickets ───────────────────────────────────────────────────────────────
  getTickets:  () => read('tickets'),

  addTicket: (ticket) => {
    const data = read('tickets');
    data.push({ ...ticket, createdAt: new Date().toISOString() });
    write('tickets', data);
  },

  closeTicket: (threadId) => {
    const data = read('tickets');
    const idx  = data.findIndex(t => t.threadId === threadId);
    if (idx === -1) return false;
    data[idx].status   = 'closed';
    data[idx].closedAt = new Date().toISOString();
    write('tickets', data);
    return true;
  },

  // ── Clients ───────────────────────────────────────────────────────────────
  getClients: ()       => read('clients'),
  getClient:  (userId) => read('clients').find(c => c.userId === userId),

  addClient: (client) => {
    const data = read('clients');
    data.push({ ...client, id: Date.now().toString(), onboardedAt: new Date().toISOString() });
    write('clients', data);
  },

  // ── Warnings ──────────────────────────────────────────────────────────────
  getWarnings: (userId) => read('warnings').filter(w => w.userId === userId),

  addWarning: (warning) => {
    const data = read('warnings');
    data.push({ ...warning, id: Date.now().toString(), createdAt: new Date().toISOString() });
    write('warnings', data);
  },
};

module.exports = db;
