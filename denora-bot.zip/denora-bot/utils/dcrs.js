// ── DENORA CREATOR RANKING SYSTEM (DCRS) ─────────────────────────────────────

const LEVELS = {
  0: { tag: 'D0', name: 'Observer',  range: '0–1K',      status: 'Prospect Pool',      budget: 'Free',           emoji: '👁️' },
  1: { tag: 'D1', name: 'Nano',      range: '1K–10K',    status: 'Community Drivers',  budget: 'Free / Incentivized', emoji: '🌱' },
  2: { tag: 'D2', name: 'Micro',     range: '10K–50K',   status: 'Growth Layer',       budget: '$20–$150',       emoji: '⚡' },
  3: { tag: 'D3', name: 'Mid-Tier',  range: '50K–250K',  status: 'Authority Builders', budget: '$150–$800',      emoji: '🔥' },
  4: { tag: 'D4', name: 'Macro',     range: '250K–1M',   status: 'Amplifiers',         budget: '$800–$3K',       emoji: '💎' },
  5: { tag: 'D5', name: 'Mega',      range: '1M+',       status: 'PR Weapons',         budget: '$3K+',           emoji: '👑' },
};

const ROLES = {
  educator:  { label: 'Educator',         emoji: '🧵', desc: 'Threads, explainers, tutorials' },
  entertainer:{ label: 'Entertainer',     emoji: '🎥', desc: 'Reels, TikTok, memes' },
  analyst:   { label: 'Analyst',          emoji: '📊', desc: 'Deep dives, alpha, insights' },
  community: { label: 'Community Driver', emoji: '🧑‍🤝‍🧑', desc: 'Spaces, Discord, engagement' },
};

const SCORE_WEIGHTS = {
  engagement:  30,
  quality:     20,
  niche:       20,
  consistency: 15,
  conversion:  15,
};

/**
 * Determine level from follower count string e.g. "45K", "1.2M", "800"
 */
function levelFromFollowers(followersStr) {
  if (!followersStr) return 0;
  const str = followersStr.toString().toUpperCase().replace(/,/g, '');
  let num = parseFloat(str);
  if (str.includes('M')) num *= 1_000_000;
  else if (str.includes('K')) num *= 1_000;
  if (num >= 1_000_000) return 5;
  if (num >= 250_000)   return 4;
  if (num >= 50_000)    return 3;
  if (num >= 10_000)    return 2;
  if (num >= 1_000)     return 1;
  return 0;
}

/**
 * Calculate total score from individual dimension scores
 */
function calcScore({ engagement, quality, niche, consistency, conversion }) {
  const e = Math.min(engagement  || 0, 30);
  const q = Math.min(quality     || 0, 20);
  const n = Math.min(niche       || 0, 20);
  const c = Math.min(consistency || 0, 15);
  const v = Math.min(conversion  || 0, 15);
  return e + q + n + c + v;
}

/**
 * Get grade letter from score
 */
function scoreGrade(score) {
  if (score >= 85) return { grade: 'S', color: 0xFFD700 };
  if (score >= 75) return { grade: 'A', color: 0x10B981 };
  if (score >= 60) return { grade: 'B', color: 0x3B82F6 };
  if (score >= 45) return { grade: 'C', color: 0xF59E0B };
  return { grade: 'D', color: 0xEF4444 };
}

/**
 * Build the creator tag string
 * e.g. "D2 Educator – Score 81 ⭐"
 */
function creatorTag(kol) {
  const level = LEVELS[kol.level ?? 0];
  const role  = ROLES[kol.role] || { label: 'Unassigned' };
  const score = kol.score ?? 0;
  const dv    = kol.verified ? ' ⭐ DV' : '';
  return `${level.tag} ${role.label} — Score ${score}${dv}`;
}

/**
 * Score bar visual (filled blocks)
 */
function scoreBar(score, max) {
  const filled = Math.round((score / max) * 8);
  return '█'.repeat(filled) + '░'.repeat(8 - filled) + ` ${score}/${max}`;
}

/**
 * Campaign stack recommendation
 * Returns an array of { level, role, count, purpose, budgetEach }
 */
function buildCampaignStack(goal, totalBudget) {
  const stacks = {
    launch: [
      { levelIdx: 1, role: 'community',  count: 30, purpose: 'Spark conversations & early buzz',   pct: 0.15 },
      { levelIdx: 2, role: 'educator',   count: 15, purpose: 'Explain product to new audiences',   pct: 0.30 },
      { levelIdx: 3, role: 'analyst',    count: 5,  purpose: 'Build credibility & trust',          pct: 0.30 },
      { levelIdx: 4, role: 'entertainer',count: 1,  purpose: 'Push mass visibility & virality',    pct: 0.25 },
    ],
    awareness: [
      { levelIdx: 1, role: 'community',  count: 20, purpose: 'Seed conversations',    pct: 0.10 },
      { levelIdx: 2, role: 'entertainer',count: 10, purpose: 'Viral content spread',  pct: 0.30 },
      { levelIdx: 3, role: 'educator',   count: 8,  purpose: 'Authority building',    pct: 0.35 },
      { levelIdx: 4, role: 'analyst',    count: 2,  purpose: 'Credibility anchor',    pct: 0.25 },
    ],
    community: [
      { levelIdx: 1, role: 'community',  count: 40, purpose: 'Discord & Spaces growth',   pct: 0.25 },
      { levelIdx: 2, role: 'educator',   count: 12, purpose: 'Onboard & educate members', pct: 0.35 },
      { levelIdx: 2, role: 'entertainer',count: 8,  purpose: 'Keep community engaged',    pct: 0.25 },
      { levelIdx: 3, role: 'community',  count: 2,  purpose: 'High-reach Spaces hosts',   pct: 0.15 },
    ],
    defi: [
      { levelIdx: 2, role: 'analyst',    count: 10, purpose: 'DeFi alpha & yield education', pct: 0.35 },
      { levelIdx: 3, role: 'analyst',    count: 5,  purpose: 'Protocol deep dives',          pct: 0.35 },
      { levelIdx: 2, role: 'educator',   count: 8,  purpose: 'Explain mechanisms',           pct: 0.20 },
      { levelIdx: 1, role: 'community',  count: 20, purpose: 'Community seeding',            pct: 0.10 },
    ],
  };

  const template = stacks[goal] || stacks.launch;
  return template.map(t => {
    const level = LEVELS[t.levelIdx];
    const role  = ROLES[t.role];
    const allocated = totalBudget ? Math.round(totalBudget * t.pct) : null;
    const perHead   = allocated && t.count > 0 ? Math.round(allocated / t.count) : null;
    return { level, role: ROLES[t.role], roleKey: t.role, count: t.count, purpose: t.purpose, pct: t.pct, allocated, perHead };
  });
}

module.exports = { LEVELS, ROLES, SCORE_WEIGHTS, levelFromFollowers, calcScore, scoreGrade, creatorTag, scoreBar, buildCampaignStack };
