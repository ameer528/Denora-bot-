const { createCanvas, loadImage } = require('@napi-rs/canvas');
const fetch = require('node-fetch');

const W = 600, H = 600;

function rng(seed) {
  let s = seed;
  return () => { s=(s*1664525+1013904223)&0xffffffff; return (s>>>0)/0xffffffff; };
}

async function fetchImageBuffer(url) {
  const res = await fetch(url);
  return res.buffer();
}

function drawCard(ctx, avatarImg, username) {
  ctx.clearRect(0,0,W,H);

  // ── Pure black base ───────────────────────────────────────────────────────
  ctx.fillStyle = '#000';
  ctx.fillRect(0,0,W,H);

  // ── Denora deep blue bloom ────────────────────────────────────────────────
  const bloom = ctx.createRadialGradient(W*0.5,H*0.26,0,W*0.5,H*0.26,W*0.75);
  bloom.addColorStop(0,   'rgba(20,10,210,0.82)');
  bloom.addColorStop(0.25,'rgba(15,5,190,0.55)');
  bloom.addColorStop(0.55,'rgba(8,2,140,0.22)');
  bloom.addColorStop(1,   'rgba(0,0,0,0)');
  ctx.fillStyle=bloom; ctx.fillRect(0,0,W,H);

  const leftG=ctx.createRadialGradient(0,H*0.4,0,0,H*0.4,220);
  leftG.addColorStop(0,'rgba(10,5,180,0.4)'); leftG.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle=leftG; ctx.fillRect(0,0,W,H);

  const rightG=ctx.createRadialGradient(W,H*0.18,0,W,H*0.18,200);
  rightG.addColorStop(0,'rgba(10,5,160,0.3)'); rightG.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle=rightG; ctx.fillRect(0,0,W,H);

  // ── Network nodes — deep blue tones ──────────────────────────────────────
  const rand=rng(42);
  const nodes=[];
  for (let i=0;i<62;i++) {
    const x=rand()*W, y=rand()*H*0.7;
    if (y>H*0.66) continue;
    nodes.push({x,y,r:rand()*1.7+0.4,bright:rand()});
  }

  for (let i=0;i<nodes.length;i++) {
    for (let j=i+1;j<nodes.length;j++) {
      const dx=nodes[i].x-nodes[j].x, dy=nodes[i].y-nodes[j].y;
      const d=Math.sqrt(dx*dx+dy*dy);
      if (d<115) {
        ctx.strokeStyle=`rgba(80,100,255,${(1-d/115)*0.35})`;
        ctx.lineWidth=0.55;
        ctx.beginPath(); ctx.moveTo(nodes[i].x,nodes[i].y); ctx.lineTo(nodes[j].x,nodes[j].y); ctx.stroke();
      }
    }
  }

  for (const n of nodes) {
    const isBright=n.bright>0.82;
    const halo=ctx.createRadialGradient(n.x,n.y,0,n.x,n.y,n.r*8);
    halo.addColorStop(0, isBright ? 'rgba(100,140,255,0.65)' : 'rgba(50,80,220,0.25)');
    halo.addColorStop(1,'rgba(0,20,180,0)');
    ctx.fillStyle=halo; ctx.beginPath(); ctx.arc(n.x,n.y,n.r*8,0,Math.PI*2); ctx.fill();
    ctx.fillStyle=isBright ? 'rgba(200,220,255,0.95)' : 'rgba(100,130,255,0.85)';
    ctx.beginPath(); ctx.arc(n.x,n.y,n.r,0,Math.PI*2); ctx.fill();
  }

  // ── Star burst — blue-white, top right ───────────────────────────────────
  const SX=W*0.78, SY=H*0.09;
  const burst=ctx.createRadialGradient(SX,SY,0,SX,SY,240);
  burst.addColorStop(0,'rgba(255,255,255,0.75)');
  burst.addColorStop(0.07,'rgba(180,210,255,0.45)');
  burst.addColorStop(0.22,'rgba(50,80,255,0.15)');
  burst.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle=burst; ctx.fillRect(0,0,W,H);

  const core=ctx.createRadialGradient(SX,SY,0,SX,SY,20);
  core.addColorStop(0,'rgba(255,255,255,1)'); core.addColorStop(1,'rgba(160,200,255,0)');
  ctx.fillStyle=core; ctx.fillRect(0,0,W,H);

  ctx.save(); ctx.translate(SX,SY); ctx.globalAlpha=0.5;
  for (let i=0;i<8;i++) {
    const a=(i/8)*Math.PI*2, len=i%2===0?88:44;
    const rg=ctx.createLinearGradient(0,0,Math.cos(a)*len,Math.sin(a)*len);
    rg.addColorStop(0,'rgba(255,255,255,0.9)'); rg.addColorStop(1,'rgba(80,120,255,0)');
    ctx.strokeStyle=rg; ctx.lineWidth=i%2===0?1.2:0.6;
    ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(Math.cos(a)*len,Math.sin(a)*len); ctx.stroke();
  }
  ctx.globalAlpha=1; ctx.restore();

  // ── Bottom fade ───────────────────────────────────────────────────────────
  const fade=ctx.createLinearGradient(0,H*0.46,0,H);
  fade.addColorStop(0,'rgba(0,0,0,0)');
  fade.addColorStop(0.3,'rgba(0,0,0,0.7)');
  fade.addColorStop(1,'rgba(0,0,0,0.97)');
  ctx.fillStyle=fade; ctx.fillRect(0,0,W,H);

  // ── Avatar ────────────────────────────────────────────────────────────────
  const ACX=W/2, ACY=H*0.36, AR=74;

  const ag=ctx.createRadialGradient(ACX,ACY,AR*0.5,ACX,ACY,AR*2);
  ag.addColorStop(0,'rgba(30,50,220,0.6)');
  ag.addColorStop(0.5,'rgba(10,20,180,0.2)');
  ag.addColorStop(1,'rgba(0,0,0,0)');
  ctx.fillStyle=ag; ctx.beginPath(); ctx.arc(ACX,ACY,AR*2,0,Math.PI*2); ctx.fill();

  // Blue-to-white ring
  const ringGrad=ctx.createLinearGradient(ACX-AR,ACY-AR,ACX+AR,ACY+AR);
  ringGrad.addColorStop(0,'rgba(100,140,255,1)');
  ringGrad.addColorStop(0.5,'rgba(255,255,255,0.95)');
  ringGrad.addColorStop(1,'rgba(40,80,220,1)');
  ctx.strokeStyle=ringGrad; ctx.lineWidth=4;
  ctx.beginPath(); ctx.arc(ACX,ACY,AR+4,0,Math.PI*2); ctx.stroke();

  // Avatar clip
  ctx.save();
  ctx.beginPath(); ctx.arc(ACX,ACY,AR,0,Math.PI*2); ctx.closePath(); ctx.clip();
  if (avatarImg) {
    ctx.drawImage(avatarImg,ACX-AR,ACY-AR,AR*2,AR*2);
  } else {
    ctx.fillStyle='#06003a'; ctx.fillRect(ACX-AR,ACY-AR,AR*2,AR*2);
    ctx.fillStyle='rgba(40,70,200,0.65)';
    ctx.beginPath(); ctx.arc(ACX,ACY-12,28,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(ACX,ACY+52,50,0,Math.PI); ctx.fill();
  }
  ctx.restore();

  // ── Username pill ─────────────────────────────────────────────────────────
  const PY=ACY+AR+30;
  const displayName = username.length > 22 ? username.slice(0,22)+'…' : username;
  ctx.font='600 17px sans-serif'; ctx.textAlign='center'; ctx.textBaseline='middle';
  const tw=ctx.measureText(displayName).width;
  const PW=tw+50, PH=33;
  ctx.fillStyle='rgba(255,255,255,0.93)';
  ctx.beginPath(); ctx.roundRect(W/2-PW/2,PY-PH/2,PW,PH,PH/2); ctx.fill();
  ctx.strokeStyle='rgba(100,140,255,0.3)'; ctx.lineWidth=1;
  ctx.beginPath(); ctx.roundRect(W/2-PW/2,PY-PH/2,PW,PH,PH/2); ctx.stroke();
  ctx.fillStyle='#04001e'; ctx.fillText(displayName,W/2,PY);

  // ── CREATOR CORNER ────────────────────────────────────────────────────────
  const HY=PY+66;
  ctx.textAlign='center'; ctx.textBaseline='alphabetic';
  ctx.shadowColor='rgba(30,60,255,0.7)'; ctx.shadowBlur=28;
  ctx.fillStyle='#ffffff';
  ctx.font='bold 78px sans-serif';
  ctx.fillText('CREATOR',W/2,HY);
  ctx.fillText('CORNER',W/2,HY+82);
  ctx.shadowBlur=0;

  // ── Denora double-D logomark ──────────────────────────────────────────────
  const BY=HY+150;
  const DX=W/2-70, DY=BY-17, DH=34;

  // Outer D
  ctx.fillStyle='#ffffff';
  ctx.fillRect(DX,DY,8,DH);
  ctx.beginPath();
  ctx.arc(DX+8,DY+DH/2,DH/2,-Math.PI/2,Math.PI/2);
  ctx.lineTo(DX+8,DY+DH); ctx.lineTo(DX+8,DY);
  ctx.closePath(); ctx.fill();

  // Inner D cutout
  ctx.fillStyle='#04001e';
  ctx.fillRect(DX+10,DY+7,5,DH-14);
  ctx.beginPath();
  ctx.arc(DX+15,DY+DH/2,(DH-14)/2,-Math.PI/2,Math.PI/2);
  ctx.lineTo(DX+15,DY+7);
  ctx.closePath(); ctx.fill();

  // Wordmark
  ctx.fillStyle='rgba(255,255,255,0.95)';
  ctx.font='bold 24px sans-serif';
  ctx.textAlign='left'; ctx.textBaseline='middle';
  ctx.fillText('Denora',DX+42,BY);

  // Tagline
  ctx.fillStyle='rgba(120,160,255,0.8)';
  ctx.font='11px sans-serif';
  ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillText('1st Web3 Growth Studio',W/2,BY+22);

  // Corner + marks
  ctx.fillStyle='rgba(80,120,255,0.4)';
  ctx.font='18px sans-serif';
  ctx.textAlign='left';  ctx.fillText('+',20,H-20);
  ctx.textAlign='right'; ctx.fillText('+',W-20,H-20);
}

async function generateCreatorCard(avatarUrl, username) {
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');

  let avatarImg = null;
  try {
    const buf = await fetchImageBuffer(avatarUrl);
    avatarImg = await loadImage(buf);
  } catch {
    // fallback to silhouette
  }

  drawCard(ctx, avatarImg, username);
  return canvas.toBuffer('image/png');
}

module.exports = { generateCreatorCard };
