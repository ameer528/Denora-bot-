const { EmbedBuilder } = require('discord.js');
const { LEVELS, ROLES, creatorTag, scoreGrade } = require('./dcrs');

const COLORS = {
  primary: 0x0A0AFF,
  success: 0x10B981,
  warning: 0xF59E0B,
  danger:  0xEF4444,
  info:    0x3B82F6,
};

const FOOTER = { text: 'Denora • 1st Web3 Growth Studio' };

function base(color = COLORS.primary) {
  return new EmbedBuilder().setColor(color).setFooter(FOOTER).setTimestamp();
}

const embeds = {
  success: (title, description) => base(COLORS.success).setTitle(`✅ ${title}`).setDescription(description),
  error:   (title, description) => base(COLORS.danger).setTitle(`❌ ${title}`).setDescription(description),
  info:    (title, description) => base(COLORS.primary).setTitle(`📌 ${title}`).setDescription(description),
  warning: (title, description) => base(COLORS.warning).setTitle(`⚠️ ${title}`).setDescription(description),

  welcome: (member) =>
    base(COLORS.primary)
      .setTitle('👋 Welcome to Denora')
      .setDescription(
        `Hey ${member}! Welcome to the **Denora** server.\n\n` +
        `We're the 1st Web3 growth studio combining strategy, execution and talent.\n\n` +
        `👇 **Who are you?** Pick a role below to get started.`
      )
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true })),

  ticketOpened: (user, reason, ticketNum) =>
    base(COLORS.primary)
      .setTitle(`🎫 Ticket #${ticketNum}`)
      .setDescription(`Support ticket opened by ${user}`)
      .addFields(
        { name: 'Reason',       value: reason || 'No reason provided' },
        { name: 'Status',       value: '🟢 Open' },
        { name: 'Instructions', value: 'Describe your issue below. A Denora team member will assist you shortly.\nClick **Close Ticket** when resolved.' }
      ),

  kolProfile: (kol) => {
    const level  = LEVELS[kol.level ?? 0];
    const role   = ROLES[kol.role] || { label: 'Unassigned', emoji: '❓' };
    const score  = kol.score ?? 0;
    const { color } = scoreGrade(score);
    const tag    = creatorTag(kol);

    return new EmbedBuilder()
      .setColor(color)
      .setTitle(`${level.emoji} ${kol.verified ? '⭐ ' : ''}${kol.name} — KOL Profile`)
      .setDescription(`**DCRS Tag:** \`${tag}\``)
      .setFooter(FOOTER)
      .setTimestamp()
      .addFields(
        { name: 'Level',        value: `${level.tag} — ${level.name} (${level.range})`, inline: true },
        { name: 'Role',         value: `${role.emoji} ${role.label}`,                    inline: true },
        { name: 'DCRS Score',   value: `${score}/100${kol.verified ? ' ⭐ DV' : ''}`,   inline: true },
        { name: 'Handle',       value: kol.handle   || 'N/A', inline: true },
        { name: 'Platform',     value: kol.platform || 'N/A', inline: true },
        { name: 'Niche',        value: kol.niche    || 'N/A', inline: true },
        { name: 'Budget Range', value: level.budget,           inline: true },
        { name: 'Campaign',     value: kol.campaign || 'Unassigned', inline: true },
        { name: 'Payment',      value: kol.paymentStatus || 'Unpaid', inline: true },
        { name: 'Deliverables', value: kol.deliverables?.length ? kol.deliverables.map(d => `• ${d.title} — \`${d.status}\``).join('\n') : 'None logged', inline: false },
        { name: 'Payments',     value: kol.payments?.length ? kol.payments.map(p => `• ${p.amount} — \`${p.status}\``).join('\n') : 'None logged', inline: false },
      );
  },

  campaignStatus: (campaign) =>
    base(COLORS.info)
      .setTitle(`📊 Campaign — ${campaign.name}`)
      .addFields(
        { name: 'Client',       value: campaign.client   || 'N/A',    inline: true },
        { name: 'Status',       value: campaign.status   || 'Active', inline: true },
        { name: 'Budget',       value: campaign.budget   || 'N/A',    inline: true },
        { name: 'Start Date',   value: campaign.startDate|| 'N/A',    inline: true },
        { name: 'End Date',     value: campaign.endDate  || 'N/A',    inline: true },
        { name: 'Goal',         value: campaign.goal     || 'N/A',    inline: true },
        { name: 'KOLs Assigned',value: campaign.kols?.length ? campaign.kols.join(', ') : 'None', inline: false },
        { name: 'Latest Update',value: campaign.updates?.length ? campaign.updates[campaign.updates.length-1].text : 'No updates yet', inline: false },
      ),

  modLog: (action, moderator, target, reason) =>
    base(COLORS.warning)
      .setTitle(`🔨 Moderation — ${action}`)
      .addFields(
        { name: 'User',      value: `${target} (${target.id})`, inline: true },
        { name: 'Moderator', value: `${moderator}`,             inline: true },
        { name: 'Reason',    value: reason || 'No reason provided' },
      ),

  clientOnboard: (user, company, pkg) =>
    base(COLORS.success)
      .setTitle('🚀 New Client Onboarded')
      .addFields(
        { name: 'Discord', value: `${user}`,  inline: true },
        { name: 'Company', value: company,    inline: true },
        { name: 'Package', value: pkg,        inline: true },
        { name: 'Status',  value: '✅ Onboarding complete' },
      ),

  report: (title, stats) => {
    const embed = base(COLORS.primary).setTitle(`📈 ${title}`);
    for (const [name, value] of Object.entries(stats)) {
      embed.addFields({ name, value: String(value), inline: true });
    }
    return embed;
  },
};

module.exports = { embeds, COLORS };
